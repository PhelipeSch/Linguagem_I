
public class Humor {
    
    protected String getHumor(){
        return "Mal-humorado";
    }
    
    public void escreveHumor(){
        System.out.println("Eu me sinto "+ getHumor()+" hoje!");
    }
}
