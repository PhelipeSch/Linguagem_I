
public class Feliz extends Humor{
    
    @Override
    protected String getHumor(){
        return "Feliz";
    }
    
    public void rir(){
        System.out.println("hehehehehhe...hahhahahhahah...  HAHAHAHAHAHAHAHAHA!!!!!");
    }
   
}
