
public class Triste extends Humor{

    protected String getHumor() {
        return "Triste";
    }
    
    public void chorar(){
        System.out.println("wahh...boo hoo...weep!!!");
    }

}
