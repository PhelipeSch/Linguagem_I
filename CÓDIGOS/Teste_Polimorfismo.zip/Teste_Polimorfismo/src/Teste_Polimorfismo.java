//Polimorfismo sobreescrito ou também chamado de polimorfismo dinâmico
public class Teste_Polimorfismo {

    public static void main(String[] args) {
        
        Humor t1 = new Humor();
        Feliz t2 = new Feliz();
        Triste t3 = new Triste();
        Psiquiatra t4= new Psiquiatra();
        
        System.out.println("Como o objeto se sente? ");
        t1.escreveHumor();
        System.out.println("");
        System.out.println("Como o objeto se sente? ");
        t2.escreveHumor();
        System.out.println("");
        System.out.println("Como o objeto se sente? ");
        t3.escreveHumor();
        System.out.println("");
        
        t4.examinar(t1);
        t4.examinar(t2);
        t4.examinar(t3);
        
        t4.observar(t2);
        t4.observar(t3);
    }

}
