
public class Psiquiatra {
    public void examinar(Humor t1){
        System.out.println("Fale-me, objeto, como voce se sente hoje?");
        t1.escreveHumor();
        System.out.println("");
    }
    
    public void observar(Triste t3){
        t3.chorar();
        System.out.println("Hum... muito interessante. Alguma coisa está fazendo este objeto sesentir triste");
        System.out.println("");
    }
    
    //Polimorfismo de sobrecarga
    public void observar(Feliz t2){
        t2.rir();
        System.out.println("Humm... muito interessante. Este objeto parece muito feliz");
        System.out.println("");
    }
}
