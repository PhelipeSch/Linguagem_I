
public class Exercicio_02 {

    public static void main(String args[]) {

        ConverterMaiusculas c1 = new ConverterMaiusculas();
        AumentarMaiusculas c2 = new AumentarMaiusculas();

        c1.aumentarLetras();

        try {
            c2.aumentarLetras2();
        } catch (NullPointerException e) {
            System.out.println("Ocorreu um NullPointerException ao executar o método aumentarLetras() " + e);
        }
    }
}
