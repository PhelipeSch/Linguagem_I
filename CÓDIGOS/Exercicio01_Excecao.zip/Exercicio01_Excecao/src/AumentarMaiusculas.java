
public class AumentarMaiusculas {

    public static void aumentarLetras2() throws NullPointerException {
        String frase = null;
        String novaFrase = null;
        novaFrase = frase.toUpperCase();
        System.out.println("Frase antiga: " + frase);
        System.out.println("Frase nova: " + novaFrase);
    }
}
