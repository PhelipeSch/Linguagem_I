
public class ConverterMaiusculas {

    public static void aumentarLetras() {
        String frase = null;
        String novaFrase = null;

        try {
            novaFrase = frase.toUpperCase();
            System.out.println("Frase antiga: " + frase);
            System.out.println("Frase nova: " + novaFrase);
        } catch (NullPointerException e) {
            System.out.println("Nao foi possivel colocar a String maiuscula, pois, ela e nula");
        }
    }
}
