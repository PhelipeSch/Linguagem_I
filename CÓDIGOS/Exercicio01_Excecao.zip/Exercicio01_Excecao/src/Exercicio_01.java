//Exceções Unchecked, são essas que estão sendo tratadas, o compilador não olha se você vai tratar elas.
//Exceções Checked Exceptions, o próprio java vai nos OBRIGAR a tratar elas.

import java.io.FileNotFoundException;

public class Exercicio_01 {

    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("Inicio do main");
        metodo1();
        int i = 5571;
        try {
            i = i / 0;
        } catch (ArithmeticException e) {
            System.out.println("ERRO: " + e);
            System.out.println("Nao conseguimos dividir por 0, desculpa!");
        }
        System.out.println("Resultado: " + i);

        try{
        metodo3();
        }
        catch(FileNotFoundException e){
            System.out.println("Nao podemos abrir o arquivo, ERRO: "+e);
        }
        System.out.println("Fim do main");
    }

    public static void metodo1() {
        System.out.println("Inicio do metodo 1");
        metodo2();
        System.out.println("Fim do metodo 1");
    }

    public static void metodo2() {
        System.out.println("Inicio metodo 2");
        int[] array = new int[10];

        for (int i = 0; i <= 15; i++) {
            try {
                array[i] = i;
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("erro: " + e);
            }
            System.out.println(i);
        }

        System.out.println("Fim do metodo 2");
    }

    public static void metodo3() throws FileNotFoundException {

        new java.io.FileInputStream("arquivo.txt");
        System.out.println("fim do metodo 3");
    }
}
