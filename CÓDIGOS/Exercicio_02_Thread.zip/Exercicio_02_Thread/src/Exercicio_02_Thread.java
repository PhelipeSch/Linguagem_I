
public class Exercicio_02_Thread {

    public static void main(String[] args) {
        MinhaThread mt1 = new MinhaThread("#1", 800);
        MinhaThread mt2 = new MinhaThread("#2", 1000);
        MinhaThread mt3 = new MinhaThread("#3", 700);
        
        mt1.start();
        mt2.start();
        mt3.start();
        
        /*
        while (mt1.isAlive() || mt2.isAlive() || mt3.isAlive()) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        */
        
        
        try {
            mt1.join();
            mt2.join();
            mt3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Programa Ok!");
    }
}
