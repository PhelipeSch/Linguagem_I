
public class Mulher extends Pessoa_IMC {

    public Mulher(double peso, double altura, String nome, String dataNascimento) {
        super(peso, altura, nome, dataNascimento);
    }
    double imc;

    public String resultIMC() {
        imc = calculaIMC(altura, peso);
        if (imc < 20.7) {
            return "Abaixo do peso ideal";
        } else {
            if (imc > 26.4) {
                return "Acima do peso ideal";
            } else {
                return "Peso ideal";
            }
        }
    }

    @Override
    public String toString() {
        return "Nome: " + nome + "\n" + "Data de Nascimento: " + dataNascimento
                + "\n" + "Peso: " + peso + "\n" + "Altura: " + altura + "\n" + "Resultado IMC: " + resultIMC();
    }

}
