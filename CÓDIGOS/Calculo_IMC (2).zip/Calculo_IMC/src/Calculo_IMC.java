
import java.util.Scanner;

public class Calculo_IMC {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        boolean rodando = true;
        int contH = 0;
        int contM = 0;
        Homem[] homens = new Homem[2];
        Mulher[] mulheres = new Mulher[2];
        

        while (rodando) {
            System.out.println("MENU");
            System.out.println("Digite [1] se voce quer criar um Homem");
            System.out.println("Digite [2] se voce quer criar uma Mulher");
            System.out.println("Digite [3] se voce quer localizar um Homem");
            System.out.println("Digite [4] se voce quer listar todos os Homem");
            System.out.println("Digite [5] se voce quer localizar uma Mulher");
            System.out.println("Digite [6] se voce quer listar todos as Mulheres");
            System.out.println("Digite [7] para sair");
            int op = leitor.nextInt();

            switch (op) {
                case 1:
                    System.out.println("Digite os dados do objeto a ser gerado: ");
                    String vazia = leitor.nextLine();
                    System.out.println("Nome: ");
                    String nome = leitor.nextLine();
                    System.out.println("Data de nascimento: ");
                    String dataNasc = leitor.nextLine();
                    System.out.println("Altura (em metros): ");
                    double altura = leitor.nextDouble();
                    System.out.println("Peso (em Kg): ");
                    double peso = leitor.nextDouble();
                    Homem h1 = new Homem(peso, altura, nome, dataNasc);
                    homens[contH] = h1;
                    contH++;
                    System.out.println(h1.toString());
                    System.out.println(homens[contH].imc);
                    System.out.println("Homem cadastrado com sucesso!");
                    System.out.println("");
                    break;

                case 2:
                    System.out.println("Digite os dados do objeto a ser gerado: ");
                    vazia = leitor.nextLine();
                    System.out.println("Nome: ");
                    String nomeM = leitor.nextLine();
                    System.out.println("Data de nascimento: ");
                    String dataNascM = leitor.nextLine();
                    System.out.println("Altura (em metros): ");
                    double alturaM = leitor.nextDouble();
                    System.out.println("Peso (em Kg): ");
                    double pesoM = leitor.nextDouble();
                    Mulher m1 = new Mulher(pesoM, alturaM, nomeM, dataNascM);
                    mulheres[contM] = m1;
                    contM++;
                    System.out.println(m1.toString());
                    System.out.println(mulheres[contM].imc);
                    System.out.println("Mulher cadastrada com sucesso!");
                    System.out.println("");
                    break;

                case 3:
                    vazia = leitor.nextLine();
                    System.out.println("Digite o nome do homem que deseja buscar");
                    String nomedps = leitor.nextLine();
                    for (int i = 0; i < 2; i++) {
                        if (nomedps.equals(homens[i].nome)) {
                            System.out.println(homens[i]);
                            System.out.println(homens[i].imc);
                        }
                    }
                    System.out.println();
                    break;
                case 4:
                    for (int i = 0; i < contH; i++) {
                        System.out.println(homens[i]);
                        System.out.println(homens[i].imc);
                        System.out.println();
                    }
                    break;
                case 5:
                    vazia = leitor.nextLine();
                    System.out.println("Digite o nome da mulher que deseja buscar");
                    String nomedpsM = leitor.nextLine();
                    for (int i = 0; i < 2; i++) {
                        if (nomedpsM.equals(mulheres[i].nome)) {
                            System.out.println(mulheres[i]);
                            System.out.println(mulheres[i].imc);
                        }
                    }
                    System.out.println();
                    break;
                case 6:
                    for (int i = 0; i < 2; i++) {
                        System.out.println(mulheres[i]);
                        System.out.println(mulheres[i].imc);
                        System.out.println();
                    }
                case 7:rodando = false;
                    break;
                default:
                    System.out.println("Nao entendi o que voce digitou!");
                    break;
            }
        }
    }
}
