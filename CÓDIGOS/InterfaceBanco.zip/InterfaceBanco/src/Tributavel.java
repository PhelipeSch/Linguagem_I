
public interface Tributavel {
    public double calculaTributos();
}
