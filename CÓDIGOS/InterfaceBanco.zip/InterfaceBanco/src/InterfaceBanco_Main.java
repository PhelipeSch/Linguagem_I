
public class InterfaceBanco_Main {

    public static void main(String[] args) {
        
        Pessoa p1 = new Pessoa(4500.00);
        System.out.println("Salario: R$ " + p1.getSalario());
        
        SeguroDeVida s1 = new SeguroDeVida(36.00);
        System.out.println("Imposto do seguro de vida: R$ " + s1.getImposto());
        
        ContaCorrente c1 = new ContaCorrente(500.00);
        System.out.println("Saldo na conta corrente: R$ " + c1.getSaldo());

        GerenciadorDeImpostoDeRenda g1 = new GerenciadorDeImpostoDeRenda();

        g1.adicionarTributos(p1);
        g1.adicionarTributos(s1);
        g1.adicionarTributos(c1);

        System.out.println("O total de Tributos e de R$ " + g1.retornaTotalTributos());

    }
}
