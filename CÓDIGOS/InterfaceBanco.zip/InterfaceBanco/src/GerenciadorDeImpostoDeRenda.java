
public class GerenciadorDeImpostoDeRenda {

    private double totalTributos;

    public GerenciadorDeImpostoDeRenda() {
        this.totalTributos = 0;
    }

    public void adicionarTributos(Tributavel t) {
        double tributo = t.calculaTributos();

        totalTributos += tributo;
    }

    public double retornaTotalTributos() {
        return totalTributos;
    }

    public double getTotalTributos() {
        return totalTributos;
    }

    public void setTotalTributos(double totalTributos) {
        this.totalTributos = totalTributos;
    }
}
