
public class Movimento {
    public static void main(String[] args) {
        
        Carro c1 = new Carro ("PH3L1P3", "Dodge RAM 3500");
        
        c1.mover();
        System.out.println("Modelo: "+c1.modelo);
        System.out.println("Placa: "+c1.placa);
    }
}
