
abstract class Veiculo {

    protected String modelo;

    public Veiculo(String modelo) {
        this.modelo = modelo;
    }

    abstract void mover();

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

}
