
public class Carro extends Veiculo {

    protected String placa;

    public Carro(String placa, String modelo) {
        super(modelo);
        this.placa = placa;
    }

    public void mover() {
        System.out.println("Estou em movimento.");
    }

    public String getModelo() {
        return modelo;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

}