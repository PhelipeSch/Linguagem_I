
public class Programacao_Concorrente {

    public static void main(String[] args) {

        Progrma p1 = new Progrma();
        p1.setId(1);

        Thread t1 = new Thread(p1);
        t1.start();

        Progrma p2 = new Progrma();
        p2.setId(2);

        Thread t2 = new Thread(p2);
        t2.start();

    }

}
