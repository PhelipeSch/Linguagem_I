
public class main_retangulo {

    public static void main(String[] args) {

        Retangulo r1 = new Retangulo();
        r1.setAltura(2.5);
        r1.setLado(8.0);

        Retangulo r2 = new Retangulo();
        r2.setAltura(7.3);
        r2.setLado(13.0);

        System.out.println("Dados dos Retângulos");

        System.out.println("Primeiro");
        System.out.println("Lado: " + r1.getLado());
        System.out.println("Altura: " + r1.getAltura());
        System.out.println("Perímetro: " + r1.calcularPerimetro());
        System.out.println("Área: " + r1.calcularArea());
        System.out.println();

        System.out.println("Segundo");
        System.out.println("Lado: " + r2.getLado());
        System.out.println("Altura: " + r2.getAltura());
        System.out.println("Perímetro: " + r2.calcularPerimetro());
        System.out.println("Área: " + r2.calcularArea());
        System.out.println();

        ControleArea c1 = new ControleArea();
        c1.registra(r1);
        c1.registra(r2);

        System.out.println("Total da Área após registrar r1 e r2: " + c1.getTotalDaArea());
        System.out.println();

        for (int i = 0; i < 10; i++) {
            double lado = 20 + i;
            double altura = 3 + i;
            Retangulo ret = new Retangulo();
            ret.setLado(lado);
            ret.setAltura(altura);

            c1.registra(ret);

            System.out.println("Retângulo " + (i + 1));
            System.out.println("Lado: " + ret.getLado());
            System.out.println("Altura: " + ret.getAltura());
            System.out.println("Perímetro: " + ret.calcularPerimetro());
            System.out.println("Área: " + ret.calcularArea());
            System.out.println("Total acumulado: " + c1.getTotalDaArea());
            System.out.println();
        }
    }
}
