
public class Retangulo extends Figura {

    private double lado;
    private double altura;

    public Retangulo() {
    }

    public double getLado() {
        return lado;
    }

    public double getAltura() {
        return altura;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public double calcularArea() {
        return lado * altura;
    }

    @Override
    public double calcularPerimetro() {
        return 2 * (lado + altura);
    }
}
