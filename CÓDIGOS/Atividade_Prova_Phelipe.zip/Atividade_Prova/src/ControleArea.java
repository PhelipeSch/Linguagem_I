 
public class ControleArea {

    private double totalDaArea;

    public ControleArea() {
        this.totalDaArea = 0;
    }

    public void registra(Figura figura) {
        this.totalDaArea += figura.calcularArea();
    }

    public double getTotalDaArea() {
        return totalDaArea;
    }

    public void setTotalDaArea(double totalDaArea) {
        this.totalDaArea = totalDaArea;
    }
}
